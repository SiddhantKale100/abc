#include<stdio.h>

#include<math.h>

void main() {

int i, n;
float x[20],y[20],da,db,ds,a,b,sum0,sum1,sum2,sum3;
printf("Enter the value of given points n="); scanf("%d",&n);

for ( i = 1; i <= n ;i++)

{ printf("\n Enter the values of x [\%d]=",i ); 
scanf("\%f",&x[i] );
}
for( i = 1; i<=n;i++)

{

printf("\n Enter the values of y [\%d]=",i);

scanf("%f",&y[i]);

}
for( i = 1; i <= n ;i++)
{
    sum0 = sum0 + x[i];
    sum1 = sum1 + y[i];
    sum2 =sum2+(x[i]*y[i]);
    sum3 =sum3+(x[i]*x[i]); 
    
}
ds=sum0*sum0-sum3*n;
da=sum1*sum0-sum2*n;
db=sum0*sum2-sum3*sum1;

printf("\n ds=%f",ds);
printf("\n da=%f",da);
printf("\n db=%f",db);
{
    a=da/ds;
    b=db/ds;
    printf("\n a=%f",a);
    
    printf("\n b=%f",b);
    printf("\n The equation of straight line is y=%fx +%f" ,a,b);
}
}