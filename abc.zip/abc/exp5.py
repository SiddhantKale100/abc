dict
1
2- mydict=f
3
'id':101,
4 'name':'Santosh'
5
'salary':76234.67
6
print(mydict)
7
8
print(len(mydict))
LO
print(mydict.keys())
10 print(mydict.values())
11 mydict['city']='Pune
12 print(mydict)
13 mydict.popitem()
14 print(mydict)
15 mydict.pop('name')
16 print(mydict)
names=['Anand','Mangesh','Sarita','Yogesh','Rahul']
 print(names)
print(names[0])
print(len(names))
names.append('Sarita')

print(names)
1
names.insert(1,'Yash')
8
print(names)
9 names.remove('Yash')
10 print(names)
11 names.pop()
12 print(names)
13- if 'Anand' in names:
14 print('Found at index ',names.index('Anand'))
15 names.remove('Anand')
16 print(names)
17. else:
18 print('Not Found')
mytuple=('Yogesh', 'Mangesh', 'Sarita')
print(mytuple)
3 print('size of tuples is ',len(mytuple))
4 mylist=list(mytuple)
5 6 7
print(mylist)
mylist.append('Mandar')
print(mylist)
8 mytuple-tuple(mylist)
9 print(mytuple)
10 print(type(mytuple))