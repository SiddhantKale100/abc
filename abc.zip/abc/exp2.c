#include <stdio.h>
#include <conio.h>
#include <math.h>

void main() {
    int i, j, n, maxit = 5;
    double a[10], b[10], c[10], p[10];

    printf("\nEnter the order of polynomial equation n = ");
    scanf("%d", &n);

    for(i = 0; i <= n; i++) {
        printf("Enter coefficient a[%d] = ", i);
        scanf("%lf", &a[i]);
    }

    printf("\nEnter the initial guess p[0] = ");
    scanf("%lf", &p[0]);

    b[0] = a[0];
    c[0] = b[0];

    j = 0;
    do {
        for(i = 1; i <= n; i++) {
            b[i] = a[i] + p[j] * b[i - 1];
            c[i] = b[i] + p[j] * c[i - 1];
        }

        p[j + 1] = p[j] - (b[n] / c[n-1]); // Corrected calculation of p[j+1]

        printf("\nAt iteration %d, p is %.6lf", j, p[j]); // Corrected printf statement

        j++;
    } while(j < maxit);

    getch();
}