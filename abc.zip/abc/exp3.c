#include <stdio.h>
#include <math.h>
#define F(c) (3*c*c - 5*c - 2)
int main() {
    float a, b, c;
    printf("\nEnter the initial values of a and b: ");
    scanf("%f %f", &a, &b);
    int i = 1;
    do {
        c = (a + b) / 2;
        
        if (F(a) * F(c) < 0) {
            b = c;
        } else {
            a = c;
        }
        printf("\ni = %d, a = %f, b = %f, c = %f, F(c) = %f", i, a, b, c, F(c));
        i++;
    } 
    while(fabs(F(c)) > 0.001 && i <= 15);
    printf("\n\nApproximate root = %.4f\n\n", c);
    return 0;
}