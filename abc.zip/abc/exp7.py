#program for RK mathod
def dydx(x, y):
    return (x + y)

# Obtain initial values
x0 = float(input("Enter the initial value of x (t''): "))
y0 = float(input("Enter the initial value of y: "))
x_target = float(input("Enter the value of x for which y is to be calculated (t''): "))
h = float(input("Enter the value of step size h (t''): "))

# Count number of iterations using step size h
n = int((x_target - x0) / h)

# Iterate for number of steps
for i in range(1, n + 1):
    # Apply Runge Kutta Formulas to find next value of y
    k1 = h * dydx(x0, y0)
    k2 = h * dydx(x0 + 0.5 * h, y0 + 0.5 * k1)
    k3 = h * dydx(x0 + 0.5 * h, y0 + 0.5 * k2)
    k4 = h * dydx(x0 + h, y0 + k3)
    k = (1/6) * (k1 + 2 * k2 + 2 * k3 + k4)

    # Update next value of y and x
    y1 = y0 + k
    x1 = x0 + h
    x0 = x1
    y0 = y1

# Print the final value of y
print("The value of y at x = {:.2f} is {:.6f}".format(x_target, y0))